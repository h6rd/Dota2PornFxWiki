import os
import re
import vpk
import tempfile

# Config
VPK_PATH = r"C:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\game\dota\pak01_dir.vpk"
INTERNAL_FILE_PATH = "resource/localization/dota_russian.txt"
REPLACE_FILE = "replace.txt"
OUTPUT_VPK = "pak02_dir.vpk"

def load_replacements(filepath):
    replacements = {}
    if not os.path.exists(filepath):
        print(f"[-] Replacement file '{filepath}' not found!")
        return replacements

    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            match = re.search(r'"([^"]+)"\s+"([^"]*)"', line)
            if match:
                key = match.group(1)
                value = match.group(2)
                replacements[key] = value

    print(f"[+] Loaded {len(replacements)} lines for replacement.")
    return replacements

def main():
    if not os.path.exists(VPK_PATH):
        print(f"[-] VPK not found at: {VPK_PATH}")
        return

    replacements = load_replacements(REPLACE_FILE)
    if not replacements:
        print("[-] No replacement data found. Exiting.")
        return

    print(f"[~] Opening {VPK_PATH}...")
    try:
        pak = vpk.open(VPK_PATH)
        vpk_file = pak.get_file(INTERNAL_FILE_PATH)
        if not vpk_file:
            print(f"[-] File '{INTERNAL_FILE_PATH}' not found inside vpk")
            return

        file_bytes = vpk_file.read()
    except Exception as e:
        print(f"[-] Error reading VPK: {e}")
        return

    try:
        text = file_bytes.decode('utf-8-sig')
    except UnicodeDecodeError:
        text = file_bytes.decode('utf-16')

    print(f"[~] Applying replacements to '{INTERNAL_FILE_PATH}'...")
    replace_count = 0

    for key, new_value in replacements.items():
        pattern = re.compile(rf'^(\s*"{re.escape(key)}"\s+")([^"]*)(")', re.MULTILINE | re.IGNORECASE)
        if pattern.search(text):
            text = pattern.sub(rf'\g<1>{new_value}\g<3>', text)
            replace_count += 1
        else:
            print(f"    [!] Key '{key}' not found in the original file.")

    print(f"[+] Successfully replaced: {replace_count} out of {len(replacements)} keys.")

    modified_bytes = text.encode('utf-8-sig')

    print(f"[~] Creating new VPK '{OUTPUT_VPK}'...")

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_file_path = os.path.join(temp_dir, os.path.normpath(INTERNAL_FILE_PATH))
        os.makedirs(os.path.dirname(temp_file_path), exist_ok=True)

        with open(temp_file_path, 'wb') as f:
            f.write(modified_bytes)

        new_pak = vpk.new(temp_dir)
        new_pak.save(OUTPUT_VPK)

    print(f"[+] Done! File saved as {OUTPUT_VPK}")

if __name__ == "__main__":
    main()
